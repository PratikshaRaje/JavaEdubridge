class Sample
{
public static void main(String[] args)
{
System.out.println("Hello World");
System.out.println("Hey there,I am Computer Engineer);
}
}